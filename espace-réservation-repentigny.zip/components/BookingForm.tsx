
import React, { useState } from 'react';
import { TIME_SLOTS, SERVICES } from '../constants';
import { Reservation } from '../types';

interface BookingFormProps {
  onAddReservation: (res: Omit<Reservation, 'id' | 'status' | 'createdAt'>) => void;
}

const BookingForm: React.FC<BookingFormProps> = ({ onAddReservation }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    date: '',
    time: TIME_SLOTS[0],
    service: SERVICES[0],
    notes: ''
  });

  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddReservation(formData as any);
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="text-center py-12 space-y-6 animate-in fade-in zoom-in duration-500">
        <div className="w-20 h-20 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center mx-auto">
          <i className="fas fa-calendar-check text-3xl"></i>
        </div>
        <h2 className="text-3xl font-black text-slate-900 tracking-tighter uppercase">Rendez-vous Demandé !</h2>
        <p className="text-slate-500 max-w-xs mx-auto">
          Merci {formData.name}. Nous préparons votre fauteuil pour le {formData.date} à {formData.time}.
        </p>
        <button 
          onClick={() => setSubmitted(false)}
          className="px-8 py-3 bg-slate-900 text-white rounded-full font-bold"
        >
          Prendre un autre rendez-vous
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-1">Nom du client</label>
          <input 
            required type="text"
            value={formData.name}
            onChange={e => setFormData({...formData, name: e.target.value})}
            className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all"
            placeholder="Ex: Sophie ou Marc"
          />
        </div>
        <div className="space-y-2">
          <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-1">Cellulaire</label>
          <input 
            required type="tel"
            value={formData.phone}
            onChange={e => setFormData({...formData, phone: e.target.value})}
            className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all"
            placeholder="514-000-0000"
          />
        </div>
      </div>

      <div className="space-y-2">
        <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-1">Service souhaité</label>
        <select 
          value={formData.service}
          onChange={e => setFormData({...formData, service: e.target.value})}
          className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all cursor-pointer appearance-none"
        >
          {SERVICES.map(s => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-1">Date</label>
          <input 
            required type="date"
            min={new Date().toISOString().split('T')[0]}
            value={formData.date}
            onChange={e => setFormData({...formData, date: e.target.value})}
            className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all cursor-pointer"
          />
        </div>
        <div className="space-y-2">
          <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-1">Heure</label>
          <select 
            value={formData.time}
            onChange={e => setFormData({...formData, time: e.target.value})}
            className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all cursor-pointer appearance-none"
          >
            {TIME_SLOTS.map(slot => <option key={slot} value={slot}>{slot}</option>)}
          </select>
        </div>
      </div>

      <div className="space-y-2">
        <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-1">Préférences / Allergies (Optionnel)</label>
        <textarea 
          rows={2}
          value={formData.notes}
          onChange={e => setFormData({...formData, notes: e.target.value})}
          className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all resize-none"
          placeholder="Ex: Dégradé à blanc, cuir chevelu sensible..."
        />
      </div>

      <button 
        type="submit"
        className="w-full py-5 bg-slate-900 hover:bg-indigo-600 text-white font-black rounded-2xl shadow-2xl transition-all flex items-center justify-center gap-3 active:scale-[0.98]"
      >
        CONFIRMER LE RENDEZ-VOUS <i className="fas fa-check-circle text-sm"></i>
      </button>
    </form>
  );
};

export default BookingForm;
