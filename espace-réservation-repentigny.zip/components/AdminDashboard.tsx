
import React, { useState } from 'react';
import { Reservation } from '../types';

interface AdminDashboardProps {
  reservations: Reservation[];
  onUpdateStatus: (id: string, status: Reservation['status']) => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ reservations, onUpdateStatus }) => {
  const [filter, setFilter] = useState<Reservation['status'] | 'all'>('all');
  const [search, setSearch] = useState('');

  const filtered = reservations
    .filter(r => filter === 'all' || r.status === filter)
    .filter(r => 
        r.name.toLowerCase().includes(search.toLowerCase()) || 
        r.phone.includes(search)
    )
    .sort((a, b) => new Date(`${a.date} ${a.time}`).getTime() - new Date(`${b.date} ${b.time}`).getTime());

  const pendingCount = reservations.filter(r => r.status === 'pending').length;

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Résumé rapide */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-indigo-50 p-4 rounded-2xl border border-indigo-100">
          <p className="text-[10px] font-black text-indigo-600 uppercase tracking-widest">En attente</p>
          <p className="text-3xl font-black text-indigo-900">{pendingCount}</p>
        </div>
        <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
          <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Total aujourd'hui</p>
          <p className="text-3xl font-black text-slate-900">
            {reservations.filter(r => r.date === new Date().toISOString().split('T')[0]).length}
          </p>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4 justify-between items-center p-2 bg-slate-100 rounded-2xl">
        <div className="relative w-full md:w-64">
          <i className="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 text-xs"></i>
          <input 
            type="text" placeholder="Chercher un nom ou tel..."
            value={search} onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-white border-none rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
          />
        </div>
        <div className="flex gap-1">
          {(['all', 'pending', 'confirmed'] as const).map((f) => (
            <button
              key={f} onClick={() => setFilter(f)}
              className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                filter === f ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              {f === 'all' ? 'Tous' : f === 'pending' ? 'Attente' : 'Confirmés'}
            </button>
          ))}
        </div>
      </div>

      <div className="grid gap-4">
        {filtered.map((res) => (
          <div key={res.id} className="bg-white p-6 rounded-[2rem] border border-slate-100 flex flex-col md:flex-row justify-between items-center gap-4 hover:shadow-xl hover:border-indigo-200 transition-all group">
            <div className="flex items-center gap-4 text-center md:text-left w-full md:w-1/3">
              <div className="w-14 h-14 bg-slate-900 rounded-2xl flex items-center justify-center text-white shrink-0 shadow-lg">
                <span className="font-black text-lg">{res.name.charAt(0)}</span>
              </div>
              <div>
                <h4 className="font-black text-slate-900 uppercase tracking-tight">{res.name}</h4>
                <a href={`tel:${res.phone}`} className="text-sm font-bold text-indigo-600 hover:underline flex items-center gap-2 justify-center md:justify-start">
                  <i className="fas fa-phone-alt text-[10px]"></i> {res.phone}
                </a>
              </div>
            </div>

            <div className="text-center md:text-left flex-1 border-y md:border-y-0 md:border-x border-slate-50 py-4 md:py-0 md:px-8">
              <p className="text-[10px] font-black text-indigo-600 uppercase tracking-widest mb-1">{res.service}</p>
              <div className="flex items-center justify-center md:justify-start gap-2">
                <i className="far fa-calendar text-slate-400"></i>
                <p className="text-sm font-bold text-slate-700">{res.date} à <span className="text-indigo-600">{res.time}</span></p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <span className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest ${
                res.status === 'confirmed' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'
              }`}>
                {res.status === 'confirmed' ? 'Confirmé' : 'À Valider'}
              </span>
              <div className="flex gap-2">
                {res.status === 'pending' && (
                  <button 
                    title="Confirmer"
                    onClick={() => onUpdateStatus(res.id, 'confirmed')}
                    className="w-11 h-11 rounded-full bg-green-600 text-white hover:bg-green-700 transition-colors flex items-center justify-center shadow-lg"
                  >
                    <i className="fas fa-check"></i>
                  </button>
                )}
                <button 
                  title="Annuler"
                  onClick={() => onUpdateStatus(res.id, 'cancelled')}
                  className="w-11 h-11 rounded-full bg-slate-100 text-slate-400 hover:bg-red-500 hover:text-white transition-all flex items-center justify-center"
                >
                  <i className="fas fa-trash-alt text-sm"></i>
                </button>
              </div>
            </div>
          </div>
        ))}
        {filtered.length === 0 && (
          <div className="text-center py-20 bg-slate-50 rounded-[3rem] border border-dashed border-slate-200">
            <i className="fas fa-calendar-times text-4xl text-slate-200 mb-4"></i>
            <p className="text-slate-400 font-bold uppercase tracking-widest text-sm">Aucun rendez-vous</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;
