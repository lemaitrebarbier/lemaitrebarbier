
import React from 'react';
import { ViewType } from '../types';
import { BUSINESS_INFO } from '../constants';

interface NavbarProps {
  currentView: ViewType;
  setView: (view: ViewType) => void;
}

const Navbar: React.FC<NavbarProps> = ({ currentView, setView }) => {
  return (
    <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center gap-2">
            <div className="bg-slate-900 p-2 rounded-lg text-white">
              <i className="fas fa-scissors text-lg"></i>
            </div>
            <span className="font-black text-lg tracking-widest uppercase hidden sm:block">
              {BUSINESS_INFO.name}
            </span>
          </div>
          
          <div className="flex items-center space-x-4">
            <button 
              onClick={() => setView('client')}
              className={`px-4 py-2 rounded-full text-xs font-black uppercase tracking-widest transition-all ${
                currentView === 'client' 
                ? 'bg-slate-900 text-white shadow-lg shadow-slate-200' 
                : 'text-slate-500 hover:bg-slate-100'
              }`}
            >
              Réserver
            </button>
            <button 
              onClick={() => setView('admin')}
              className={`px-4 py-2 rounded-full text-xs font-black uppercase tracking-widest transition-all ${
                currentView === 'admin' 
                ? 'bg-slate-900 text-white shadow-lg shadow-slate-200' 
                : 'text-slate-500 hover:bg-slate-100'
              }`}
            >
              Gérant
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
